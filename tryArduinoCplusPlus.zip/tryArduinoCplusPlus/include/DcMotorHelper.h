// Header file
// Make Sure your file name
// should be my_library.h
#ifndef DCMOTORHELPER_H
#define DCMOTORHELPER_H

#include <Arduino.h>

class DCMotor 
{
  private:
    byte pin1;
    byte pin2;
    int speed;

  public:
    DCMotor(byte, byte, int);
    void clockwise();
    void antiClockwise();
    void stop();
    void motorDelay();
};

#endif
