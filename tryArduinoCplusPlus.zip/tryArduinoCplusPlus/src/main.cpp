#include <Arduino.h>
#include "DcMotorHelper.h"



// Main code.

void setup() 
{
  // put your setup code here, to run once:
}

DCMotor myDcMotor(9, 10, 200);

void loop() 
{
  // put your main code here, to run repeatedly:
  myDcMotor.antiClockwise();
  myDcMotor.motorDelay();
  myDcMotor.clockwise();
  myDcMotor.motorDelay();
}

